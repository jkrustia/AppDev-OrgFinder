using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using OrgFinder.Models;

namespace OrgFinder.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        // Sample data (replace with database or other data source)
        ViewBag.Departments = new List<string> { 
            "College of Accountancy and Finance (CAF)", 
            "College of Architecture, Design and the Built Environment (CADBE)", 
            "College of Arts and Letters (CAL)", 
            "College of Business Administration (CBA)",
            "College of Communication (COC)",
            "College of Computer and Information Sciences (CCIS)",
            "College of Education (COED)",
            "College of Engineering (CE)",
            "College of Human Kinetics (CHK)",
            "College of Political Science and Public Administration (CPSPA)",
            "College of Social Sciences and Development (CSSD)",
            "College of Science (CS)",
            "College of Tourism, Hospitality and Transportation Management (CTHTM)" };

        ViewBag.Programs = new Dictionary<string, List<string>>
        {
            { "College of Accountancy and Finance (CAF)", new List<string> 
                { 
                    "Bachelor of Science in Accountancy (BSA)", 
                    "Bachelor of Science in Business Administration Major in Financial Management (BSBAFM)", 
                    "Bachelor of Science in Management Accounting (BSMA)" } },
            
            { "College of Architecture, Design and the Built Environment (CADBE)", new List<string> 
                { 
                    "Bachelor of Science in Architecture (BS-ARCH)", 
                    "Bachelor of Science in Environmental Planning (BSEP)" } },

            { "College of Arts and Letters (CAL)", new List<string> 
                { 
                    "Bachelor of Arts in English Language Studies (ABELS)", 
                    "Bachelor of Arts in Filipinology (ABF)", 
                    "Bachelor of Arts in Literary and Cultural Studies (ABLCS)",
                    "Bachelor of Arts in Philosophy (AB-PHILO)",
                    "Bachelor of Performing Arts major in Theater Arts (BPEA)" } },

            { "College of Business Administration (CBA)", new List<string> 
                { 
                    "Bachelor of Science in Business Administration major in Human Resource Management (BSBAHRM)", 
                    "Bachelor of Science in Business Administration major in Marketing Management (BSBA-MM)",
                    "Bachelor of Science in Entrepreneurship (BSENTREP)", 
                    "Bachelor of Science in Office Administration (BSOA)" } },

            { "College of Communication (COC)", new List<string> 
                { 
                    "Bachelor in Advertising and Public Relations (BADPR)", 
                    "Bachelor of Arts in Broadcasting (BA Broadcasting)", 
                    "Bachelor of Arts in Communication Research (BACR)",
                    "Bachelor of Arts in Journalism (BAJ)" } },

            { "College of Computer and Information Sciences (CCIS)", new List<string> 
                { 
                    "Bachelor of Science in Computer Science (BSCS)", 
                    "Bachelor of Science in Information Technology (BSIT)" } },

            { "College of Education (COED)", new List<string> 
                { 
                    "Bachelor of Technology and Livelihood Education (BTLEd)", 
                    "Bachelor of Library and Information Science (BLIS)", 
                    "Bachelor of Secondary Education (BSEd)",
                    "Bachelor of Elementary Education (BEEd)",
                    "Bachelor of Early Childhood Education (BECEd)" } },

            { "College of Engineering (CE)", new List<string> 
                { 
                    "Bachelor of Science in Civil Engineering (BSCE)", 
                    "Bachelor of Science in Computer Engineering (BSCpE)", 
                    "Bachelor of Science in Electrical Engineering (BSEE)",
                    "Bachelor of Science in Electronics Engineering (BSECE)",
                    "Bachelor of Science in Industrial Engineering (BSIE)",
                    "Bachelor of Science in Mechanical Engineering (BSME)",
                    "Bachelor of Science in Railway Engineering (BSRE)" } },

            { "College of Human Kinetics (CHK)", new List<string> 
                { 
                    "Bachelor of Physical Education (BPE)", 
                    "Bachelor of Science in Exercises and Sports (BSESS)" } },

            { "College of Political Science and Public Administration (CPSPA)", new List<string> 
                { 
                    "Bachelor of Arts in Political Science (BAPS)", 
                    "Bachelor of Arts in Political Economy (BAPE)", 
                    "Bachelor of Arts in International Studies (BAIS)",
                    "Bachelor of Public Administration (BPA)" } },

            { "College of Social Sciences and Development (CSSD)", new List<string> 
                { 
                    "Bachelor of Arts in History (BAH)", 
                    "Bachelor of Arts in Sociology (BAS)", 
                    "Bachelor of Science in Cooperatives (BSC)",
                    "Bachelor of Science in Economics (BSE)",
                    "Bachelor of Science in Psychology (BSPSY)" } },

            { "College of Science (CS)", new List<string> 
                { 
                    "Bachelor of Science Food Technology (BSFT)", 
                    "Bachelor of Science in Applied Mathematics (BSAPMATH)", 
                    "Bachelor of Science in Biology (BSBIO)",
                    "Bachelor of Science in Chemistry (BSCHEM)",
                    "Bachelor of Science in Mathematics (BSMATH)",
                    "Bachelor of Science in Nutrition and Dietetics (BSND)",
                    "Bachelor of Science in Physics (BSPHY)",
                    "Bachelor of Science in Statistics (BSSTAT)" } },

            { "Science", new List<string> 
                { 
                    "Bachelor of Science in Hospitality Management (BSHM)", 
                    "Bachelor of Science in Tourism Management (BSTM)", 
                    "Bachelor of Science in Transportation Management (BSTRM)" } }
            
        };

        ViewBag.Interests = new List<string> 
        {
            // Academic/Career
            "Business", "Technology", "Science", "Engineering", "Humanities", 
            "Social Sciences", "Medicine", "Law", "Education", 

            // Creative
            "Arts & Crafts", "Music", "Writing", "Design", "Photography", 

            // Extracurricular
            "Sports", "Travel", "Gaming", "Volunteering",  

            // Personal
            "Health & Wellness", "Nature", "Culture", "Social Issues", 

            // Other
            "Research", "Innovation", "Leadership", "Community Building"
        };

        return View();
    }

    [HttpPost]  // Important: This must be a POST request since you're submitting a form
    public IActionResult Results(StudentProfile profile) // Correct: Receive the StudentProfile
    {
        // 1. Check if the profile is null (important for debugging):
        if (profile == null) 
        {
            // Log this or handle it appropriately.  This means the form data isn't reaching the action.
            return View(new List<Organization>()); // Return an empty list to avoid null exception in view
        }

        // Sample organization data (replace with your actual data)
        var organizations = new List<Organization> { 
            new Organization 
                { 
                    Name = "PUP Harana String Co.", 
                    Website = "https://www.facebook.com",
                    Department = "College of Engineering (CE)", 
                    Programs = new List<string> { "Bachelor of Science in Civil Engineering (BSCE)" }, 
                    Interests = new List<string> { "Music" } },

            new Organization 
                { 
                    Name = "String Co.", 
                    //Website = "https://www.facebook.com",
                    Department = "College of Engineering (CE)", 
                    Programs = new List<string> { "Bachelor of Science in Civil Engineering (BSCE)" }, 
                    Interests = new List<string> { "Music" } },
                    
            
            /*
            new Organization 
                { 
                    Name = "Tech Club", 
                    Department = "Engineering", 
                    Programs = new List<string> { "Computer Science" }, 
                    Interests = new List<string> { "Technology" } },
            */

            //new Organization { Name = "Art Society", Department = "Arts", Interests = new List<string> { "Arts" } },
            new Organization { Name = "Sports Club", Interests = new List<string> { "Sports" } }
         };

        var results = organizations
            .Where(org => 
                profile.Department == null ||  // User didn't select a department OR
                string.Equals(org.Department, profile.Department, StringComparison.OrdinalIgnoreCase) || // Department matches (case-insensitive) OR
                string.IsNullOrEmpty(org.Department) // Organization has NO department listed
            )
            .Where(org => 
                profile.Program == null || // User didn't select a program OR
                (org.Programs != null && org.Programs.Any(program => string.Equals(program, profile.Program, StringComparison.OrdinalIgnoreCase))) || // Program matches (case-insensitive) OR
                org.Programs == null || org.Programs.Count == 0 // Organization has NO programs listed
            )
            .Where(org => profile.Interests.Any(interest => org.Interests.Any(orgInterest => string.Equals(orgInterest, interest, StringComparison.OrdinalIgnoreCase)))) // Interests (case-insensitive)
            .ToList();

        // 2. Check if results is null or empty after filtering (important for debugging):
        if (results == null || results.Count == 0)
        {
            // Log this.  It means no organizations matched the criteria.
        }

        return View(results); // This line is absolutely essential!
    }


    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
