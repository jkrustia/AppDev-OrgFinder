using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OrgFinder.Views.Home
{
    public class ResultsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
