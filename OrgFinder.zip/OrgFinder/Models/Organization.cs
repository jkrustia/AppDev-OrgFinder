using System;

namespace OrgFinder.Models;

public class Organization
{
    public string Name { get; set; }
    public string Description { get; set; }
    public string Website { get; set; }
    public bool OpenToAll { get; set; }
    public List<string> AllowedPrograms { get; set; } = new List<string>();
    public List<string> RequiredInterests { get; set; } = new List<string>();
}
