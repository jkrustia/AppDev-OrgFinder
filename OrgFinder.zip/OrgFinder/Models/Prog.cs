using System;

namespace OrgFinder.Models;

public class Prog
{
    public string Name { get; set; }
    public List<Prog> Programs { get; set; } = new List<Prog>();
}
