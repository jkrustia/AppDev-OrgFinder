using System;

namespace OrgFinder.Models;

public class Interest
{
    public string Name { get; set; }
    public ICollection<Organization> Organizations { get; set; }
}
