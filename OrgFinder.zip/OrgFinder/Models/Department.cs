using System;

namespace OrgFinder.Models;

public class Department
{
    public string Name { get; set; }
    public List<Prog> Programs { get; set; } = new List<Prog>();
    public List<Prog> Prog { get; internal set; }
}
