using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using OrgFinder.Models;

namespace OrgFinder.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        ViewBag.Departments = DataInitializer.Departments;
        ViewBag.Interests = DataInitializer.Interests;
        return View();
    }

    [HttpPost]
    public IActionResult GetResults(string department, string program, List<string> selectedInterests)
    {
        var filteredOrganizations = DataInitializer.Organizations
            .Where(o => 
                (o.OpenToAll || o.AllowedPrograms.Contains(program)) && 
                o.RequiredInterests.All(i => selectedInterests.Contains(i))
            )
            .ToList();

        ViewBag.Results = filteredOrganizations;
        return View("Results");
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
