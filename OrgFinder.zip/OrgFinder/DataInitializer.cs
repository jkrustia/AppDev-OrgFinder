using System.Collections.Generic;
using OrgFinder.Models;

namespace OrgFinder
{
    public static class DataInitializer
    {
        public static List<Department> Departments { get; } = new List<Department>
        {
            new Department
            {
                Name = "College of Accountancy and Finance (CAF)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science in Accountancy (BSA)" },
                    new Prog { Name = "Bachelor of Science in Business Administration Major in Financial Management (BSBAFM)" },
                    new Prog { Name = "Bachelor of Science in Management Accounting (BSMA)" }
                }
            },

            new Department
            {
                Name = "College of Architecture, Design and the Built Environment (CADBE)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science in Architecture (BS-ARCH)" },
                    new Prog { Name = "Bachelor of Science in Architecture (BS-ARCH)" },
                    new Prog { Name = "Bachelor of Science in Environmental Planning (BSEP)" }
                }
            },

            new Department
            {
                Name = "College of Arts and Letters (CAL)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Arts in English Language Studies (ABELS)" },
                    new Prog { Name = "Bachelor of Arts in Filipinology (ABF)" },
                    new Prog { Name = "Bachelor of Arts in Literary and Cultural Studies (ABLCS)" },
                    new Prog { Name = "Bachelor of Arts in Philosophy (AB-PHILO)" },
                    new Prog { Name = "Bachelor of Performing Arts major in Theater Arts (BPEA)" }
                }
            },

            new Department
            {
                Name = "College of Business Administration (CBA)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science in Business Administration major in Human Resource Management (BSBAHRM)" },
                    new Prog { Name = "Bachelor of Science in Business Administration major in Marketing Management (BSBA-MM)" },
                    new Prog { Name = "Bachelor of Science in Entrepreneurship (BSENTREP)" },
                    new Prog { Name = "Bachelor of Science in Office Administration (BSOA)" }
                }
            },

            new Department
            {
                Name = "College of Communication (COC)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor in Advertising and Public Relations (BADPR)" },
                    new Prog { Name = "Bachelor of Arts in Broadcasting (BA Broadcasting)" },
                    new Prog { Name = "Bachelor of Arts in Communication Research (BACR)" },
                    new Prog { Name = "Bachelor of Arts in Journalism (BAJ)" }
                }
            },

            new Department
            {
                Name = "College of Computer and Information Sciences (CCIS)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science in Computer Science (BSCS)" },
                    new Prog { Name = "Bachelor of Science in Information Technology (BSIT)" }
                }
            },

            new Department
            {
                Name = "College of Education (COED)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Technology and Livelihood Education (BTLEd)" },
                    new Prog { Name = "Bachelor of Library and Information Science (BLIS)" },
                    new Prog { Name = "Bachelor of Secondary Education (BSEd)" },
                    new Prog { Name = "Bachelor of Elementary Education (BEEd)" },
                    new Prog { Name = "Bachelor of Early Childhood Education (BECEd)" }
                }
            },

            new Department
            {
                Name = "College of Engineering (CE)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science in Civil Engineering (BSCE)" },
                    new Prog { Name = "Bachelor of Science in Computer Engineering (BSCpE)" },
                    new Prog { Name = "Bachelor of Science in Electrical Engineering (BSEE)" },
                    new Prog { Name = "Bachelor of Science in Electronics Engineering (BSECE)" },
                    new Prog { Name = "Bachelor of Science in Industrial Engineering (BSIE)" },
                    new Prog { Name = "Bachelor of Science in Mechanical Engineering (BSME)" },
                    new Prog { Name = "Bachelor of Science in Railway Engineering (BSRE)" }
                }
            },

            new Department
            {
                Name = "College of Human Kinetics (CHK)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Physical Education (BPE)" },
                    new Prog { Name = "Bachelor of Science in Exercises and Sports (BSESS)" }
                }
            },

            new Department
            {
                Name = "College of Political Science and Public Administration (CPSPA)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Arts in Political Science (BAPS)" },
                    new Prog { Name = "Bachelor of Arts in Political Economy (BAPE)" },
                    new Prog { Name = "Bachelor of Arts in International Studies (BAIS)" },
                    new Prog { Name = "Bachelor of Public Administration (BPA)" }
                }
            },

            new Department
            {
                Name = "College of Social Sciences and Development (CSSD)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Arts in History (BAH)" },
                    new Prog { Name = "Bachelor of Arts in Sociology (BAS)" },
                    new Prog { Name = "Bachelor of Science in Cooperatives (BSC)" },
                    new Prog { Name = "Bachelor of Science in Economics (BSE)" },
                    new Prog { Name = "Bachelor of Science in Psychology (BSPSY)" }
                }
            },

            new Department
            {
                Name = "College of Science (CS)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science Food Technology (BSFT)" },
                    new Prog { Name = "Bachelor of Science in Applied Mathematics (BSAPMATH)" },
                    new Prog { Name = "Bachelor of Science in Biology (BSBIO)" },
                    new Prog { Name = "Bachelor of Science in Chemistry (BSCHEM)" },
                    new Prog { Name = "Bachelor of Science in Mathematics (BSMATH)" },
                    new Prog { Name = "Bachelor of Science in Nutrition and Dietetics (BSND)" },
                    new Prog { Name = "Bachelor of Science in Physics (BSPHY)" },
                    new Prog { Name = "Bachelor of Science in Statistics (BSSTAT)" }
                }
            },

            new Department
            {
                Name = "College of Tourism, Hospitality and Transportation Management (CTHTM)",
                Prog = new List<Prog>
                {
                    new Prog { Name = "Bachelor of Science in Hospitality Management (BSHM)" },
                    new Prog { Name = "Bachelor of Science in Tourism Management (BSTM)" },
                    new Prog { Name = "Bachelor of Science in Transportation Management (BSTRM)" }
                }
            },
            
        };

        public static List<Organization> Organizations { get; } = new List<Organization>
        {
            new Organization
            {
                Name = "Computer Science Society",
                Description = "For all Computer Science students.",
                Website = "https://www.css.org",
                OpenToAll = false,
                AllowedPrograms = new List<string> { "BS Computer Science", "BS Information Technology" },
                RequiredInterests = new List<string> { "Programming", "Networking" }
                
            },

            new Organization
            {
                Name = "Pylon Esports",
                Description = "Pylon Esports is looking for legendary players to join our esports teams.",
                Website = "https://www.facebook.com/PylonEsports/",
                OpenToAll = true,
                //AllowedPrograms = new List<string> { "BS Computer Science", "BS Information Technology" },
                RequiredInterests = new List<string> { "Sports", "Gaming" }
            },
            // Add more organizations here
        };

        public static List<string> Interests { get; } = new List<string>
        {
            // Academic/Career
            "Business", "Technology", "Science", "Engineering", "Humanities", 
            "Social Sciences", "Arts", "Healthcare", "Law", "Education", 

            // Creative
            "Arts & Crafts", "Music", "Writing", "Design", "Photography", 

            // Extracurricular
            "Sports", "Travel", "Gaming", "Volunteering", "Community Service", 

            // Personal
            "Health & Wellness", "Nature", "Culture", "Social Issues", 

            // Other
            "Research", "Innovation", "Leadership", "Community Building"
        };

    }
}